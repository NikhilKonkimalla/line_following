Historical Archive of Older Firmwares

We're keeping this around for posterity.  If you're here you're either a curious hacker or you're lost.  Probably lost though . . .