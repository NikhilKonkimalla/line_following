Updating the Firmware for the BrickPi

This directory contains the batch files and firmware for updating.  