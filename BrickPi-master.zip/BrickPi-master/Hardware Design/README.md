BrickPi Hardware
=====

Read [more about the BrickPi here](http://www.dexterindustries.com/BrickPi)

These files have been made available online through a [Creative Commons Attribution-ShareAlike 3.0](http://creativecommons.org/licenses/by-sa/3.0/) license.

## Getting Started

We've devoted some effort to making sure that it's easy to get started.  If you're lost, we would like to first direct you to our [website for the BrickPi](http://www.dexterindustries.com/BrickPi/)

## This Repository

This repository only holds our latest hardware designs.  

[Dexter Industries](http://www.dexterindustries.com/)
[BrickPi](http://www.dexterindustries.com/BrickPi)
