Turret Model
=====

These are the design files for the BrickPi, developed by Dexter Industries.

These files have been made available online through a [Creative Commons Attribution-ShareAlike 3.0](http://creativecommons.org/licenses/by-sa/3.0/) license.

You are welcome to distribute, remix, and use these files for commercial purposes. If you do so, please attribute the original design to Dexter Industries both on the website and on the physical packaging of the product or in the instruction manual. All derivative works must be published under the same or a similar license.

## What's Here

**Turret / Shooter** — [Find more on the turret model car here.](http://www.dexterindustries.com/BrickPi/projects/shooter/)
