#! /bin/bash
sudo apt-get update
cd /tmp/
wget https://raw.githubusercontent.com/DexterInd/BrickPi/master/Setup%20Files/install.sh
chmod +x install.sh
./install.sh

