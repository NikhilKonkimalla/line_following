##Script for debugging the BrickPiScratch python usage
NOTE: THIS IS FOR DEVELOPERS ONLY.  Average user need not do this.

1. Make both **BrickPiScratchdebug.sh** and **BrickPi_Scratch_Start.sh** execuatable:

  > sudo chmod +x BrickPiScratch_debug.sh

  > sudo chmod +x BrickPi_Scratch_Start.sh

2. Copy **BrickPi_Scratch_Start.desktop** to **/usr/share/applications/**
3. Make a desktop Shortcut from **Desktop->Education->BrickPi_Scratch_Start**
3. Double click on **BrickPi_Scratch_Start** to start running the script


