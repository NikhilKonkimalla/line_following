#! /bin/bash
lxterminal --command "/home/pi/Desktop/BrickPi_Scratch/BrickPi_Scratch_Scripts/BrickPiScratch_debug.sh"
