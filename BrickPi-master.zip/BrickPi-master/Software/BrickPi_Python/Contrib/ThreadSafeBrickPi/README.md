Thread Safe Python interface to BrickPi
=======================================

This repository contains drivers and examples for using the thread safe python interface to BrickPi.

These files have been made available online through a [Creative Commons Attribution-ShareAlike 3.0](http://creativecommons.org/licenses/by-sa/3.0/) license.